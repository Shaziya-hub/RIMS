package com.rootware.meetingrooms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RimsAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(RimsAppApplication.class, args);
    }
}
