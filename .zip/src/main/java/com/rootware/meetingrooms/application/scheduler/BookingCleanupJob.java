package com.rootware.meetingrooms.application.scheduler;

public class BookingCleanupJob {

}
