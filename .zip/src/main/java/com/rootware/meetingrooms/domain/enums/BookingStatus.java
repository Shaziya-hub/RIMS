package com.rootware.meetingrooms.domain.enums;

public enum BookingStatus {

	 BOOKED,
	 COMPLETED,
	 CANCELLED
}
