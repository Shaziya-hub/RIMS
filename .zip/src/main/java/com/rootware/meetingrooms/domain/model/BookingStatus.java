package com.rootware.meetingrooms.domain.model;

public class BookingStatus {

}
