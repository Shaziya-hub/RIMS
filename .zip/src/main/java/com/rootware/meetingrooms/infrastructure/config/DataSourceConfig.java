package com.rootware.meetingrooms.infrastructure.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DataSourceConfig {
    // Placeholder for any datasource customization if needed later
}
