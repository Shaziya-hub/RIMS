package com.rootware.meetingrooms.infrastructure.external;

import org.springframework.stereotype.Component;

@Component
public class CalendarSyncAdapter {
    public void syncBookingToCalendar(Object booking) {
        // integrate with calendar provider
    }
}
