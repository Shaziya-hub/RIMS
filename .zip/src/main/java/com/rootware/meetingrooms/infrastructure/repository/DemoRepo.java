package com.rootware.meetingrooms.infrastructure.repository;

public class DemoRepo {

}
