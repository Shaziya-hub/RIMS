package com.rootware.meetingrooms.presentation.exception;

public class RoomNotFoundException extends RuntimeException {
	
	public RoomNotFoundException(String message) {
		super(message);
	}

}
