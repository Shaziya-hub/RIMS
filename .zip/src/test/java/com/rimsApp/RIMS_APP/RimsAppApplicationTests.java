package com.rimsApp.RIMS_APP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RimsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
